package com.as3somyah.oauthserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OauthAuthorizationServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
